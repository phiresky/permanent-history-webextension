module.exports = {
	/*ignoreFiles: [
		"yarn.lock",
		"package.json",
		"tsconfig.json",
		"webpack.config.js",
		"web-ext.config.js",
	],*/
}
